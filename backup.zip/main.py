import base64
import json
import datetime
from google.cloud import netapp_v1

# Define naming convention and label
BACKUP_LABEL_KEY = "backup_type"
BACKUP_LABEL_VALUE = "scheduled_backup"
NAME_PREFIX = "backup-"

def create_volume_backup(cloud_event):
    print("Received Pub/Sub trigger for NetApp Volume Backup creation.")
    
    # Decode Pub/Sub message
    message = base64.b64decode(cloud_event["data"]["message"]["data"]).decode()
    json_message = json.loads(message)
    
    # Define required variables
    myregion = "us-central1"  # Replace with your region if needed
    myvolume = "your-volume-name"  # Replace with your volume name
    myproject = "your-project-id"  # Replace with your project ID
    
    # Generate a timestamped backup name
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_name = f"{NAME_PREFIX}{myvolume}-{timestamp}"
    
    # Create a client
    client = netapp_v1.NetAppClient()
    
    # Define the volume resource name
    volume_name = f"projects/{myproject}/locations/{myregion}/volumes/{myvolume}"
    
    # Define the backup creation request
    backup_request = netapp_v1.CreateBackupRequest(
        parent=volume_name,
        backup_id=backup_name,
        backup=netapp_v1.Backup(
            labels={BACKUP_LABEL_KEY: BACKUP_LABEL_VALUE}
        )
    )
    
    try:
        # Make the request to create the backup
        print(f"Initiating backup for volume: {volume_name}")
        operation = client.create_backup(request=backup_request)
        
        # Wait for the operation to complete
        response = operation.result()
        print(f"Backup created successfully: {response.name}")
    except Exception as e:
        print(f"Error creating backup: {e}")
